﻿
Array.prototype.remove = function(from, to) {
  var rest = this.slice((to || from) + 1 || this.length);
  this.length = from < 0 ? this.length + from : from;
  return this.push.apply(this, rest);
};

function generateGuid() {
    var t = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx';
    return t.replace(/[xy]/g, function(c) {
        var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
        return v.toString(16).toUpperCase();
    });
}

function debugMessage(msg) {
    console.log(msg);
}

function htmlEncode(s) {
    return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); 
}

function StickyWallProxy(uri,localWall) {
    this.uri = uri;
    this.localWall = localWall;
    this.sockOpen = false;
}

StickyWallProxy.prototype.connect = 
function() {
    if(this.uri) {
        debugMessage("StickyWallProxy->initialize: Connecting to shared wall ("+this.uri+")");
    
        if (window.WebSocket) {
            // Chrome, Safari, Firefox 11, Internet Explorer 10
            this.sock = new WebSocket(this.uri);
        } else if (window.MozWebSocket) {
            // Firefox 7-10
            this.sock = new MozWebSocket(this.uri);
        } else {
            debugMessage("StickyWallProxy->initialize: WebSockets Not Supported!");
        }
    
        if(this.sock) {
            this.sock.onmessage = (function(ref) { return function(e) { ref.recvMsg(e.data) } })(this);
            this.sock.onopen = (function(ref) { return function(e) { ref.sockOpen = true; ref.requestNoteList(); } })(this);
            this.sock.onclose = (function(ref) { return function(e) { ref.sockOpen = false; } })(this);
        }
    }
}

StickyWallProxy.prototype.disconnect =
function() {
    if(this.sock) {
        debugMessage("StickyWallProxy->disconnect: Disconnecting from shared wall ("+this.uri+")");
        this.sendMsg("PEER QUIT "+this.localWall.wallId);
        this.sock.close();
        this.sock = null;
    }
}

StickyWallProxy.prototype.sendMsg = 
function(msg) {
    debugMessage("StickyWallProxy->sendMsg: "+msg.substring(0,100)+"...");
    if(this.sockOpen) {
        // Send Message To Remote Server
        
        this.sock.send(msg);
        // Temp Debug
        //this.recvMsg("local}>>"+msg);
    } else {
        // Local Mode (Loopback)
        this.recvMsg("local}>>"+msg);
    }
}

StickyWallProxy.prototype.recvMsg = 
function(msg) {
    debugMessage("StickyWallProxy->recvMsg: "+msg.substring(0,100)+"...");

    var from = "";
    var cmd = "";
    var msgStart = "}>>";
    var msgStartIdx = msg.indexOf(msgStart);
    if(msgStartIdx > 0) {
        from = msg.substring(0,msgStartIdx);
        cmd = msg.substring(msgStartIdx+3);
    }

    if(this.processNoteEditRequest(cmd,from) || 
       this.processNoteRemoveRequest(cmd,from) ||
       this.processNoteEditAnnounce(cmd,from) || 
       this.processNoteRemoveAnnounce(cmd,from) ||
       this.processNoteListRequest(cmd,from) ||
       this.processPeerQuit(cmd,from)) {
        debugMessage("StickyWallProxy->recvMsg: Message Processing Complete");
    } else {
        debugMessage("StickyWallProxy->recvMsg: Unknown Message, Not Processed");
    }
}

StickyWallProxy.prototype.requestNoteEdit =
function(note) {
    this.sendMsg("NOTE REQEDIT "+$.toJSON(note));
}

StickyWallProxy.prototype.requestNoteRemove = 
function(note) {
    this.sendMsg("NOTE REQREMOVE "+$.toJSON(note));
}

StickyWallProxy.prototype.requestNoteList = 
function() {
    this.sendMsg("NOTE REQLIST");
}

StickyWallProxy.prototype.announceNoteEdit =
function(note) {
    this.sendMsg("NOTE EDIT "+$.toJSON(note));
}

StickyWallProxy.prototype.announceNoteRemove = 
function(note) {
    this.sendMsg("NOTE REMOVE "+$.toJSON(note));
}

StickyWallProxy.prototype.processNoteEditRequest =
function(cmd,from) {
    var testCmd = "NOTE REQEDIT ";
    if (cmd.substring(0,testCmd.length) === testCmd) {
        debugMessage("StickyWallProxy->processNoteEditRequest: Command Received");
        // Request Edit
        var note = $.evalJSON(cmd.substring(testCmd.length));
        if (note.owner === this.localWall.wallId) {
            this.localWall.onNoteRequestEdit(note,from);
        }
        return true;
    }
    return false;
}

StickyWallProxy.prototype.processNoteRemoveRequest = 
function(cmd,from) {
    var testCmd = "NOTE REQREMOVE ";
    if(cmd.substring(0,testCmd.length) === testCmd) {
        debugMessage("StickyWallProxy->processNoteRemoveRequest: Command Received");
        // Request Remove
        var note = $.evalJSON(cmd.substring(testCmd.length));
        if(note.owner === this.localWall.wallId) {
            this.localWall.onNoteRequestRemove(note,from);
        }
        return true;
    }
    return false;
}

StickyWallProxy.prototype.processNoteEditAnnounce =
function(cmd,from) {
    var testCmd = "NOTE EDIT ";
    if(cmd.substring(0,testCmd.length) === testCmd) {
        debugMessage("StickyWallProxy->processNoteEditAnnounce: Command Received");
        // Perform Edit
        var note = $.evalJSON(cmd.substring(testCmd.length));
        debugMessage("note.owner = "+note.owner);
        debugMessage("wall.id = "+this.localWall.wallId);
        if(note.owner != this.localWall.wallId) {
            this.localWall.onNoteAnnounceEdit(note,from);
        }
        return true;
    }
    return false;
}

StickyWallProxy.prototype.processNoteRemoveAnnounce =
function(cmd,from) {
    var testCmd = "NOTE REMOVE ";
    if(cmd.substring(0,testCmd.length) === testCmd) {
        debugMessage("StickyWallProxy->processNoteRemoveAnnounce: Command Received");
        // Perform Remove
        var note = $.evalJSON(cmd.substring(testCmd.length));
        if(note.owner != this.localWall.wallId) {
            this.localWall.onNoteAnnounceRemove(note,from);
        }
        return true;
    }
    return false;
}

StickyWallProxy.prototype.processNoteListRequest =
function(cmd,from) {
    var testCmd = "NOTE REQLIST";
    if(cmd.substring(0,testCmd.length) === testCmd) {
        debugMessage("StickyWallProxy->processNoteListRequest: Command Received");
        this.localWall.onNoteRequestList();
        return true;
    }
    return false;
}

StickyWallProxy.prototype.processPeerQuit =
function(cmd,from) {
    var testCmd = "PEER QUIT ";
    if(cmd.substring(0,testCmd.length) === testCmd) {
        debugMessage("StickyWallProxy->processPeerQuit: Command Received");
        var clientId = cmd.substring(textCmd.length);
        this.localWall.onPeerQuit(clientId);
        return true;
    }
    return false;
}

function StickyWall(proxyUri) {
    this.wallId = 'client'+generateGuid()
    this.proxyUri = proxyUri;
    this.localNotes = [];
    this.remoteNotes = [];
    this.recycledNotes = [];
    this.noteColors = ["FFFF66","FFDD9D","FFBEE0","BCDEC5"] // Yellow,Orange,Pink,Green
    this.storageKey = "StickyNotesHtml5";
    this.initialize();
}

StickyWall.prototype.initialize = 
function() {
    var refWall = this;
    debugMessage("StickyWall->initialize: Wall Id = "+this.wallId);

    this.noteForm = $("#sticky-note-form");

    var notepadIdPrefix = 'notepad';
    for(var colorIndex = 0; colorIndex < this.noteColors.length; colorIndex++) {
        debugMessage('StickyWall->initialize: Creating Notepad '+this.noteColors[colorIndex]);
        var notepadStyle = '';
        var foreColor = "#000000";
        var backColor = "#"+this.noteColors[colorIndex];
        notepadStyle += 'width:120px; font-size: smaller; height:40px;';
        notepadStyle += 'color:'+foreColor+'; background-color:'+backColor+';'
        var notepadId = notepadIdPrefix+colorIndex;

        var notepadHtml = '<div id="'+notepadId+'" style="'+notepadStyle+'"></div>';
        $('#sticky-notepad-tray').append(notepadHtml);
        $('#'+notepadId).click( function() { 
            var id = $(this).attr('id').substring(notepadIdPrefix.length);
            refWall.createNewNote('#000000','#'+refWall.noteColors[id]);
        });
    }


    $('#trash-can').droppable({
        accept: '.sticky-note',
        drop: function (event, item) {
            if(confirm('Delete this note?')) {
                var $element = item.draggable;

                refWall.removeNote($element.attr('id'));
            }
        }
    });
    
    this.noteForm.dialog({
        width: 640,
    	height: 480,
    	modal: true,
        autoOpen: false,
        buttons: { "Save Note" : function() { refWall.editNote(); $(this).dialog('close'); },
                   "Cancel"    : function() { $(this).dialog('close'); }
                 },
        open:  function() { refWall.startNoteEdit() },
        close: function() { refWall.endNoteEdit() }
    });

    this.loadNotesFromStorage();
    this.cmdProxy = new StickyWallProxy(this.proxyUri, this);
    this.cmdProxy.connect();
}

StickyWall.prototype.startNoteEdit = 
function() {
    debugMessage('StickyWall->startNoteEdit: Starting Edit')
    if(this.currentNote) {
        $('#note-form-title').val(this.currentNote.title);
        $('#note-form-text').val(this.currentNote.text);
        $('#note-form-text').focus();
    }
}

StickyWall.prototype.endNoteEdit = 
function() {
    debugMessage('StickyWall->endNoteEdit: Ending Edit');
    $('.note-form-editbox').val('');
}

StickyWall.prototype.editNote =
function() {
    debugMessage('StickyWall->saveNoteEdit: Saving Note')
    if(this.currentNote) {
        this.currentNote.title = $('#note-form-title').val()
        this.currentNote.text = $('#note-form-text').val();
        this.cmdProxy.requestNoteEdit(this.currentNote);
        this.currentNote = null;
    }
}

StickyWall.prototype.removeNote = 
function(noteId) {
    var note = this.getNoteById(noteId);

    if(note) {
        this.cmdProxy.requestNoteRemove(note);
    }
}

StickyWall.prototype.getNoteById = 
function(noteId) {
    var localIdx = this.getLocalNoteIndex(noteId);
    if (localIdx >= 0) {
        return this.localNotes[localIdx];
    }

    var remoteIdx = this.getRemoteNoteIndex(noteId);
    if(remoteIdx >= 0) {
        return this.remoteNotes[remoteIdx];
    }

    return null;
}

StickyWall.prototype.onNoteRequestEdit = 
function(note,client) {
    if(!this.isRecycled(note.id)) {
        this.editLocalNote(note);
        this.cmdProxy.announceNoteEdit(note);
    }
}

StickyWall.prototype.onNoteAnnounceEdit = 
function(note,client) {
    this.editRemoteNote(note);
}

StickyWall.prototype.onNoteRequestRemove = 
function(note,client) {
    this.removeLocalNote(note);
    this.cmdProxy.announceNoteRemove(note);
}

StickyWall.prototype.onNoteAnnounceRemove = 
function(note,client) {
    this.removeRemoteNote(note.id);
}

StickyWall.prototype.onNoteRequestList = 
function() {
    // List all notes implemented as a note edit announcement (cheaty!)
    for (var ix=0; ix < this.localNotes.length; ix++) {
        this.cmdProxy.announceNoteEdit(this.localNotes[ix]);
    }
}

StickyWall.prototype.onPeerQuit =
function(client) {
    for(var ix=this.remoteNotes.length-1;ix >= 0; ix--) {
        if(this.remoteNotes[ix].owner === client) {
            this.removeRemoteNote(this.remoteNotes[ix].id);
        }
    }
}

StickyWall.prototype.recycleLocalNote =
function(note) {
    this.recycledNotes.push(note);
    $("#trash-can-img").attr("src","./images/trash_full.png")
}

StickyWall.prototype.editLocalNote = 
function(note) {
    var noteIndex = this.getLocalNoteIndex(note.id);
    if(noteIndex < 0) {
        debugMessage('StickyWall->editLocalNote: Local Note not found ('+note.id+'), adding');
        this.localNotes.push(note);
    } else {
        debugMessage('StickyWall->editLocalNote: Local Note found ('+note.id+'), editing');
        this.localNotes[noteIndex] = note;
    }
    this.saveNotesToStorage();
    this.drawNote(note);
    this.setTopmostNote(note);
}

StickyWall.prototype.editRemoteNote = 
function(note) {
    var noteIndex = this.getRemoteNoteIndex(note.id);
    if(noteIndex < 0) {
        debugMessage('StickyWall->editRemoteNote: Remote Note not found ('+note.id+'), adding');
        this.remoteNotes.push(note);
    } else {
        debugMessage('StickyWall->editRemoteNote: Remote Note not found ('+note.id+'), editing');
        this.remoteNotes[noteIndex] = note;
    }
    this.drawNote(note);
    this.setTopmostNote(note);
}

StickyWall.prototype.createNewNote =
function(foreColor,backColor) {
    var noteId = 'note'+generateGuid()
    this.currentNote = new StickyNote(noteId);
    this.currentNote.owner = this.wallId;
    this.currentNote.foreColor = foreColor;
    this.currentNote.backColor = backColor;
    
    var noteTime = new Date();
    this.currentNote.title = 
            noteTime.getFullYear()+'-'
            +(noteTime.getMonth() < 10 ? '0':'') + noteTime.getMonth()+'-'
            +(noteTime.getDate() < 10 ? '0':'')  + noteTime.getDate()+' '
            +(noteTime.getHours() < 10 ? '0':'') + noteTime.getHours()+':'
            +(noteTime.getMinutes() < 10 ? '0':'') + noteTime.getMinutes();

    if(this.noteForm) {
        this.noteForm.dialog('open');
    }
}

StickyWall.prototype.getLocalNoteIndex = 
function(noteId) {
    debugMessage('StickyWall->getLocalNoteIndex: Looking for note ('+noteId+')');
    for (var i=0; i < this.localNotes.length; i++) {
        if (this.localNotes[i].id == noteId) {
            debugMessage('StickyWall->getLocalNoteIndex: Note found')
            return i;
        }
    }
    debugMessage('StickyWall->getLocalNoteIndex: Note NOT found')
    return -1;
}

StickyWall.prototype.getRemoteNoteIndex = 
function(noteId) {
    debugMessage('StickyWall->getRemoteNoteIndex: Looking for note ('+noteId+')');
    for (var i=0; i < this.remoteNotes.length; i++) {
        if (this.remoteNotes[i].id == noteId) {
            debugMessage('StickyWall->getRemoteNoteIndex: Note found')
            return i;
        }
    }
    debugMessage('StickyWall->getRemoteNoteIndex: Note NOT found')
    return -1;
}

StickyWall.prototype.getRecycledNoteIndex = 
function(noteId) {
    debugMessage('StickyWall->getRecycledNoteIndex: Looking for note ('+noteId+')');
    for (var i=0; i < this.recycledNotes.length; i++) {
        if (this.recycledNotes[i].id == noteId) {
            debugMessage('StickyWall->getRecycledNoteIndex: Note found')
            return i;
        }
    }
    debugMessage('StickyWall->getRecycledNoteIndex: Note NOT found')
    return -1;
}

StickyWall.prototype.isRecycled =
function(noteId) {
    return this.getRecycledNoteIndex(noteId) >= 0;
}

StickyWall.prototype.removeLocalNote = 
function(note) {
    this.recycleLocalNote(note);
    var ix = this.getLocalNoteIndex(note.id);
    if(ix >= 0) {
        this.eraseNote(note.id,true);
        this.localNotes.remove(ix);
        this.saveNotesToStorage();
    }
}

StickyWall.prototype.removeRemoteNote = 
function(noteId) {
    var ix = this.getRemoteNoteIndex(noteId);
    if(ix >= 0) {
        this.eraseNote(noteId,true);
        this.remoteNotes.remove(ix);
    }
}

StickyWall.prototype.setTopmostNote = 
function(note) {
    debugMessage('StickyWall->setTopmostNote: Setting Top Most ('+note.id+')');
    var max_z = 0, min_z = 0;
    var select_z = function(index,value) { 
        var elem = $(this);
        var z = parseInt(elem.css('z-index') || 0);
        if (index == 0 || z > max_z) { max_z = z; }
        if (index == 0 || z < min_z) { min_z = z; }
    }
    var update_z = function(index,value) {
        var elem = $(this);
        var z = parseInt(elem.css('z-index') || 0);
        elem.css('z-index',(z - min_z));
    }
    $(".sticky-note").each(select_z)
    $(".sticky-note").each(update_z)

    var elem = $(".sticky-note#"+note.id);
    elem.css('z-index',(max_z-min_z+1))
}

StickyWall.prototype.drawNote = 
function(note) {
    this.eraseNote(note.id,false);
    debugMessage('StickyWall->drawNote: Drawing note ('+note.id+')');

    var noteRemoteClass = "";
    if(note.owner != this.wallId) {
        noteRemoteClass = " sticky-note-remote";
    }
    var noteTitleHtml = '<div class="sticky-note-title">'+htmlEncode(note.title)+'</div>';
    var noteBodyHtml = '<div class="sticky-note-body">'+noteTitleHtml+htmlEncode(note.text).replace(/\\n/,"<br>")+'</div>';
    var noteHtml = '<div class="sticky-note'+noteRemoteClass+'" id="'+note.id+'">'+noteBodyHtml+'</div>';
    $(".sticky-wall").append(noteHtml);

    var refWall = this;

    noteElem = $(".sticky-note#"+note.id)
    if(noteElem) {
        noteElem.draggable({
            start: function() { refWall.onNoteDragStart(note); },
            stop: function() { 
                var posTop = $(this).css('top'); 
                var posLeft = $(this).css('left'); 
                refWall.onNoteDragStop(note,posTop,posLeft);
            }
        });

        noteElem.css('color',note.foreColor);
        noteElem.css('background-color',note.backColor);
        noteElem.css('top',note.positionTop);
        noteElem.css('left',note.positionLeft);
        noteElem.bind('click', function() { refWall.onNoteClick(note) });
        noteElem.bind('dblclick', function() { refWall.onNoteDoubleClick(note) });

        var noteRot = 'rotate('+note.rotation+'deg)';
        var bodyRot = 'rotate('+(note.rotation*-1)+'deg)';
        var cssNote = {"-ms-transform":noteRot,"-moz-transform":noteRot,
                       "-webkit-transform":noteRot,"transform":noteRot}
        var cssBody = {"-ms-transform":bodyRot,"-moz-transform":bodyRot,
                       "-webkit-transform":bodyRot,"transform":bodyRot}
        $(".sticky-note#"+note.id).css(cssNote)
        $(".sticky-note#"+note.id+" .sticky-note-body").css(cssBody)
    } 
}

StickyWall.prototype.eraseNote = 
function(noteId,animate) {
    debugMessage('StickyWall->eraseNote: Erasing note ('+noteId+')');
    var elemId = ".sticky-note#"+noteId;
    if(animate) {
        $(elemId).hide('scale', {}, 'fast', function() { $(this).remove(); });
    } else {
        $(elemId).remove();
    }
}

StickyWall.prototype.loadNotesFromStorage = 
function() {
    debugMessage("StickyWall->loadNotesFromStorage: Loading Notes");
    if(localStorage) {
        var storedNotes = localStorage.getItem(this.storageKey);
        if(storedNotes) {
            var notesArray = $.evalJSON(storedNotes);
            for(var noteIndex = 0; noteIndex < notesArray.length; noteIndex++) {
                var note = notesArray[noteIndex];
                note.owner = this.wallId;
                debugMessage($.toJSON(note));
                this.localNotes.push(note);
            }

            this.drawLocalNotes();
        }
    }
}

StickyWall.prototype.drawLocalNotes =
function() {
    for(var noteIndex = 0; noteIndex < this.localNotes.length; noteIndex++) {
        this.drawNote(this.localNotes[noteIndex]);
    }
}

StickyWall.prototype.saveNotesToStorage = 
function() {
    debugMessage("StickyWall->saveNotesToStorage: Saving Notes");
    if(localStorage) {
        var storedNotes = $.toJSON(this.localNotes);
        localStorage.setItem(this.storageKey, storedNotes);
    }
}

StickyWall.prototype.onNoteDragStart = 
function(note) {
    debugMessage('StickyWall->onNoteDragStart: Starting Drag note ('+note.id+')');
    this.setTopmostNote(note);
}

StickyWall.prototype.onNoteDragStop = 
function(note,newTop,newLeft) {
    debugMessage('StickyWall->onNoteDragEnd: Ending Drag note ('+note.id+')');
    this.setTopmostNote(note);
    note.positionTop = newTop;
    note.positionLeft = newLeft;
    this.cmdProxy.requestNoteEdit(note);
}

StickyWall.prototype.onNoteClick = 
function(note) {
    this.setTopmostNote(note);
}

StickyWall.prototype.onNoteDoubleClick = 
function(note) {
    this.currentNote = note;

    if(this.noteForm) {
        this.noteForm.dialog('open');
    }
}

function StickyNote(noteId,noteValues) {
    var randomTop = Math.floor(Math.random()*501) + 40;
    var randomLeft = Math.floor(Math.random()*501) + 40;
    var randomRot = Math.floor(Math.random()*6)-3;
    var currentDate = new Date();

    var noteDefaults = {
        title: "New Note",
        text: "",
        foreColor: "000000",
        backColor: "FFFF00",
        positionTop: randomTop,
        positionLeft: randomLeft,
        rotation: randomRot,
        created: currentDate,
        updated: currentDate
    };
    $.extend(this,noteDefaults)
    $.extend(this,noteValues || {});
    this.id = noteId;
}

$(function() {
    $('p').bind('click', function() {
        var h = $(this).html()
        $(this).html(h + '<br>' + 'foo');
    });
});

var wall = null;

$(document).ready(function() { 
    wall = new StickyWall("ws://localhost:9000"); 
})


