
import sys
from twisted.internet import reactor
from twisted.python import log
from autobahn.websocket import WebSocketServerFactory, WebSocketServerProtocol, listenWS
 
 
class StickyWallServerProtocol(WebSocketServerProtocol):
    def onOpen(self):
        self.factory.register(self)
    
    def onMessage(self, msg, binary):
        if not binary:
            self.factory.broadcast("%s}>>%s" % (self.peerstr,msg))
 
    def connectionLost(self, reason):
        WebSocketServerProtocol.connectionLost(self, reason)
        self.factory.unregister(self)
 
 
class StickyWallServerFactory(WebSocketServerFactory):
    protocol = StickyWallServerProtocol
 
    def __init__(self, url):
        WebSocketServerFactory.__init__(self, url)
        self.clients = []
 
    def register(self, client):
        if not client in self.clients:
            print "Client Registering: " + client.peerstr
            self.clients.append(client)
 
    def unregister(self, client):
        if client in self.clients:
            print "Client Unregistering: " + client.peerstr
            self.clients.remove(client)
 
    def broadcast(self, msg):
        print "Broadcasting: '%s' .." % msg
        for c in self.clients:
            print "Sending to: " + c.peerstr
            c.sendMessage(msg)
 
if __name__ == '__main__':
    log.startLogging(sys.stdout)
    factory = StickyWallServerFactory("ws://localhost:9000")
    listenWS(factory)
    reactor.run()

